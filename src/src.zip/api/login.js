import http from "@/axios"

export const login = (data) => http({
  url: '/login',
  method: 'get',
  params: {
    username: data.username,
    password: data.password
  }
})

export const test = () => http({
  url: 'http://localhost:9899/hello'
})