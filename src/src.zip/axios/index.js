import axios from 'axios'

// axios实例
const http = axios.create({
  baseURL: 'http://localhost:8989/api',
  timeout: 1000
})

// 请求拦截器
http.interceptors.request.use(config => {
  console.log(config)
  return config
})

// 响应拦截器
http.interceptors.response.use(res => {
  console.log(res)
  return res
})

export default http