<template>
  <el-container style="height: 100%;">
    <el-header>Header</el-header>
    <el-main>
      <router-view></router-view>
    </el-main>
    <el-footer>Footer</el-footer>
  </el-container>
</template>