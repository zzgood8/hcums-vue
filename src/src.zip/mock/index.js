import Mock from 'mockjs'

Mock.setup({
  timeout: 100
})

console.log('ok')
Mock.mock('http://localhost:9899/api/login', {
  heelo: 'yes'
})
