import { createRouter, createWebHashHistory } from "vue-router"
import BaseLayout from "@/layout/BaseLayout.vue"
import HomeLayout from "@/layout/HomeLayout.vue"
// import BlankLayout from "@/layout/BlankLayout.vue"

const routes = [
  {
    path: "/",
    redirect: "/login",
    component: BaseLayout,
    children: [
      {
        path: "/login",
        component: () => import("@/views/Login.vue"),
      }
    ]
  },
  {
    path: '/home',
    redirect: '/home/index',
    component: HomeLayout,
    children: [
      {
        path: '',
        component: () => import('@/views/Home.vue')
      }
    ]

  }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router
